<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'cd12240_center' );

/** Database username */
define( 'DB_USER', 'cd12240_center' );

/** Database password */
define( 'DB_PASSWORD', 'gKL3102gKL3102' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '3C<Zp&2`&.kDDCE$qHE gg`:_Mfr,BwLKjTJzk^gwYMxz$%xd]3f`/d7?&v`LEtf' );
define( 'SECURE_AUTH_KEY',  '|Eg@1}),D][){nx.AH]b,MkU`:&8y,J(:k1/~1~>}[j9<u}1fvu9}k|m]TCQ;lMN' );
define( 'LOGGED_IN_KEY',    'LWw[/L;<($+8h=OH@9s8)9p#-07*U^Inu)[+cD0[02AY8#KaJ[y4/SW`]7{Nb,>E' );
define( 'NONCE_KEY',        '$!{ZonDl[G&4PHxN &BI#}4d__||Xt 1xyghl|w0n`TS-5K1&#py9mRTQ<jtE]E-' );
define( 'AUTH_SALT',        'a42=(NQ.K4_kef-&+<BX(I+$@S:= |[50neC1&tirP3CS9 0D+@Dw7slcLKl+}5P' );
define( 'SECURE_AUTH_SALT', 'f7>Hb72QhGtF~]nm_6&:-10tyIIa$PGi,E3c-Fh~YDC4-^nY-xk8XM)a>&M`o}|R' );
define( 'LOGGED_IN_SALT',   'TZG{[pAyKww5UbtD/$z=&GdkQmK}Fb:TjnMGB`0,u.KSS`/r#@,Z!I]j<EI[2vpQ' );
define( 'NONCE_SALT',       'GZ1=s(Yu2Ih?!LiENAfoty`<C%)1FF#NpfqZbVm<W$2D/d/x-F$Q_eb,U,~*)5)E' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
